import './bootstrap';

import Alpine from 'alpinejs';
import "./bootstrap";
import "laravel-datatables-vite";
import Swal from "sweetalert2/dist/sweetalert2.js";
import "sweetalert2/src/sweetalert2.scss";

window.Alpine = Alpine;

Alpine.start();
