<!-- Footer Start -->
<footer class="footer mt-auto py-3 bg-white text-center">
    <div class="container">
        <span class="text-muted"> Copyright © <span id="year"></span> <a href="https://www.omsatyamachines.com/"
                class="text-primary fw-semibold">omsatya</a>.
            Designed with <span class="bi bi-heart-fill text-danger"></span> by <a
                href="https://www.addonwebtech.com/">
                <span class="fw-semibold text-primary text-decoration-underline">Addonwebtech</span>
            </a> All
            rights
            reserved
        </span>
    </div>
</footer>
<!-- Footer End -->